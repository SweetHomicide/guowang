module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://115.29.185.110:9528/"',
  API_IMAGE: '"http://115.29.185.110:9100"'
}
