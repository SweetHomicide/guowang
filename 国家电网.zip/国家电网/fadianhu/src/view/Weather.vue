<template>
  <div class="Weather">
  <iframe width="237" scrolling="no" height="124" frameborder="0" allowtransparency="true" src="http://i.tianqi.com/index.php?c=code&id=12&color=%23FFFFFF&bdc=%23&icon=5&num=1&py=shanghai"></iframe>
  </div>
</template>

<script>
export default {
  name: 'Weather',
  data () {
    return {
    }
  }
}
</script>

<style>
  #mobile4 {
    width: auto;
    height: 60px;
    overflow: hidden;
    cursor: pointer;
    background-color: rgb(9, 171, 123);
  }
</style>
