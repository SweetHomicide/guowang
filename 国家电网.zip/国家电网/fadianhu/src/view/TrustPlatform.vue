<template>
  <div class="trustPlatform">
  	<div class="t_content">
  		<p>企业级价值信任平台</p>
  		<ul>
  			<li><img src="../assets/images/t1.png" alt="" /></li>
  			<li><img src="../assets/images/t2.png" alt="" /></li>
  			<li><img src="../assets/images/t3.png" alt="" /></li>
  			<li><img src="../assets/images/t4.png" alt="" /></li>
  			<li><img src="../assets/images/t5.png" alt="" /></li>
  		</ul>
  		<ul>
  			<li style="margin-left: 10%;"><img src="../assets/images/t6.png" alt="" /></li>
  			<li><img src="../assets/images/t7.png" alt="" /></li>
  			<li><img src="../assets/images/t8.png" alt="" /></li>
  			<li><img src="../assets/images/t9.png" alt="" /></li>
  		</ul>
  	</div>
  </div>
</template>

<script>

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.trustPlatform{
	width: 100%;
	height: 637px;
	background: -webkit-linear-gradient(#03B17D 0px,#01746D 637px); /* Safari 5.1 - 6.0 */
    background: -o-linear-gradient(#03B17D 0px,#01746D 637px); /* Opera 11.1 - 12.0 */
    background: -moz-linear-gradient(#03B17D 0px,#01746D 637px); /* Firefox 3.6 - 15 */
    background: linear-gradient(#03B17D 0px,#01746D 637px); /* 标准的语法（必须放在最后） */
}
.t_content{
	width: 1200px;
	margin: 0 auto;
}
p{
  font-size: 30px;
  padding-top: 28px;
  color: #FFF;
  text-align: center;
  margin-bottom: 19px;
}
ul{
	padding: 0;
  list-style: none;
}

li {
  display: inline-block;
  margin-right: 30px;
}
</style>
