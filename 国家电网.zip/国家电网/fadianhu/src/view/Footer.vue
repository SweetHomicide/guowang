<template>
  <div class="footer">
   <div class="f_content">
   	<div class="againw">
            <div class="links">
                <a href="#">京ICP备012345678</a>|
                <a href="#">RSS订阅</a>|
                <a href="#">电子邮件</a>|
                <a href="#">联系我们</a>|
                <a href="#">常见问题解答</a>|
                <a href="#">法律声明</a>|
                <a href="#">网站地图</a>|
                <a href="#">网站标识</a>
            </div>
            <div class="copyright">
              国家电网公司 &nbsp;www.sgcc.com.cn &nbsp;版权所有  &nbsp;&nbsp;Copyright &copy; 2003-2017 State Grid Corporation of China (SGCC). All rights reserved  <br />
              地址 北京市西城区西长安街86号 &nbsp;&nbsp;邮编 100031  &nbsp;&nbsp;网站电话 010-63415242 &nbsp;&nbsp;网站传真 010-63415242 &nbsp;&nbsp;企业邮箱 E_mail:<a

              href="mailto:sgcc-info@sgcc.com.cn">sgcc-info@sgcc.com.cn</a> <br />
              国家电网公司对外联络部主办 | 国家电网公司信息通信分公司制作维护<br>
            </div>
     </div>
   </div>
  </div>
</template>

<script>

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.footer{
	width: 100%;
	height: 190px;
	background-color: #01595D;
}
.f_content{
	width: 1200px;
	margin: 0 auto;
}
.againw{
	padding-top: 60px;
}
.links{
	font-size:14px;
	color: #FFF;
}
a{
	color: #FFF;
  text-decoration: none;
	margin: 0 40px;
}
.copyright{
	font-size: 14px;
	padding-top: 20px;
	color: #CBD6D7;
  text-align: center;
}
</style>
