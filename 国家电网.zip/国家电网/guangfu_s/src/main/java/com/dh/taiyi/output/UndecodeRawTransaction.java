package com.dh.taiyi.output;

public class UndecodeRawTransaction extends CfosOutput<String> {
	
	public String getRawTransaction() {
		return result;
	}
	
}
