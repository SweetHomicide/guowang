package com.dh.taiyi.output;

import java.math.BigDecimal;

public class Balance extends CfosOutput<BigDecimal>{
	
	public BigDecimal getBalance() {
		return result;
	}
}
