package com.dh.guangfu.vo;

import com.dh.system.base.BaseEntity;

public class CmsTypeQuery extends BaseEntity {
	
}