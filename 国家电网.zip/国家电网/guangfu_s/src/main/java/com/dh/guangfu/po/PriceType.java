package com.dh.guangfu.po;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
/**
 * 价格类型表
 * @author liliangliang
 *
 */
public class PriceType implements Serializable{
	private static final long serialVersionUID = 1L;
	private Long id;
	@NotNull(message = "用户名称不能为空") 
	private String code; //类型代码
	@NotNull(message = "用户名称不能为空") 
	private String name; //类别名称
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
