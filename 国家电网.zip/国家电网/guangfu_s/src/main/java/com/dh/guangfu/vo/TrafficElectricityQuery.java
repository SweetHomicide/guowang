package com.dh.guangfu.vo;

import java.util.Date;

import com.dh.system.base.BaseEntity;

public class TrafficElectricityQuery extends BaseEntity {
	public String year;
	public String month;
	public Date startDate;
	public Date endDate;
	private Long user_id ;//用户id



	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Long getUser_id() {
		return user_id;
	}
	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
}