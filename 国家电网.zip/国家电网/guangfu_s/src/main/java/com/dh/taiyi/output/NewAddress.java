package com.dh.taiyi.output;

public class NewAddress extends CfosOutput<String> {
	
	public String getAddress() {
		return result;
	}
	
}
