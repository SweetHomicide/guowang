package com.dh.system.po;

import java.io.Serializable;

import com.github.pagehelper.PageInfo;

/**
 * 系统角色模块
 * 
 * @author liliangliang
 *
 */
public class SysRole implements Serializable {

	private static final long serialVersionUID = -1701262098005947942L;
	/** 角色id */
	private Long id;
	/** 描述 */
	private String modules;
	/** 角色名称 */
	private String name;
	/** 角色-->资源集合 */
	private Long[] moduleId;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getModules() {
		return modules;
	}
	public void setModules(String modules) {
		this.modules = modules;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long[] getModuleId() {
		return moduleId;
	}
	public void setModuleId(Long[] moduleId) {
		this.moduleId = moduleId;
	}

	
}