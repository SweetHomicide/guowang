package com.dh.guangfu.service;

import com.dh.guangfu.po.ServerData;
import com.dh.system.base.BaseDao;

public interface ServerDataService extends BaseDao{
	

	void save(ServerData serverData);
}
