package com.dh.guangfu.service;

import java.util.List;

import com.dh.guangfu.po.Area;
import com.dh.guangfu.po.Price;
import com.dh.guangfu.vo.PriceQuery;
import com.dh.system.base.BaseDao;
import com.dh.utils.PageInfo;
/***
 * 区域管理
 * @author liliangliang
 *
 */
public interface AreaService{
	Area fingById(Long arrayid);

	List<Area> fingAllByCityId(Integer city_id);
}
