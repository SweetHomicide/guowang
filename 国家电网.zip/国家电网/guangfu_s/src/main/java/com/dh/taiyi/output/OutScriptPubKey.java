package com.dh.taiyi.output;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

public class OutScriptPubKey {

	@JSONField(name = "asm")
	private String asm;

	@JSONField(name = "hex")
	private String hex;

	@JSONField(name = "reqSigs")
	private Long reqSigs;

	@JSONField(name = "type")
	private String type;

	@JSONField(name = "addresses")
	private List<String> addresses;

	public String getAsm() {
		return asm;
	}

	public void setAsm(String asm) {
		this.asm = asm;
	}

	public String getHex() {
		return hex;
	}

	public void setHex(String hex) {
		this.hex = hex;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getReqSigs() {
		return reqSigs;
	}

	public void setReqSigs(Long reqSigs) {
		this.reqSigs = reqSigs;
	}

	public List<String> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<String> addresses) {
		this.addresses = addresses;
	}

}
