package com.dh.guangfu.po;

import java.io.Serializable;
import java.util.Date;
/**
 * 价格表
 * @author liliangliang
 *
 */
public class Price implements Serializable{
	private static final long serialVersionUID = 1L;
	private Long id;
	private String code; //价格类型代码
	private Double price; //单价
	private Date create_date;//创建日期
	private Date end_date;//截止日期
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
}
