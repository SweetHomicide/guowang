package com.dh.guangfu.vo;

import com.dh.system.base.BaseEntity;

public class UserMeterQuery extends BaseEntity {
	private Integer status; //状态  0 待审核  1 已审核   2 已拒绝
	private Long[] arrayId;
	private String remark;
	
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Long[] getArrayId() {
		return arrayId;
	}

	public void setArrayId(Long[] arrayId) {
		this.arrayId = arrayId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
}