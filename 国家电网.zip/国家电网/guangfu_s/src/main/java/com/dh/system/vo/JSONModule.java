package com.dh.system.vo;

public class JSONModule {
	private Long id;
	private Children[] children;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Children[] getChildren() {
		return children;
	}
	public void setChildren(Children[] children) {
		this.children = children;
	}
	
}
