package com.dh.guangfu.po;

import java.util.Date;

public class CmsInfo {
    private Long id;

    private String title;//标题

    private Long cmstypeid;//类型

    private Date createdate;//创建日期

    private Integer sort; //排序

    private Integer status;// 0 下线  1 上线

    private String content;//文本内容

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public Long getCmstypeid() {
        return cmstypeid;
    }

    public void setCmstypeid(Long cmstypeid) {
        this.cmstypeid = cmstypeid;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }
}