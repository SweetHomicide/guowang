package com.dh.taiyi.common;

public enum NodeAction
{
    add,
    remove,
    onetry
}