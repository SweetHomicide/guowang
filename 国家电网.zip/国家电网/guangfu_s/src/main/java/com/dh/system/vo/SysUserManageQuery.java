package com.dh.system.vo;

import com.dh.system.base.BaseEntity;

/**
 * 系统角色模块
 *
 */
public class SysUserManageQuery  extends  BaseEntity {

	/** 用户名 */
	private String username;
	private Long  arrayid;
	/** 头像 */
	private String head;
	/**昵称 */
	private String nickname;
	/** 提现密码 */
	private String pay_password;
	/**省*/
	private String province;
	/**市*/
	private String city;
	/**县*/
	private String county;
	private String oldpassword;
	private String password;
	private Integer area_id;
	private Integer type;//0 个人     1 国网
	
	
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getArea_id() {
		return area_id;
	}
	public void setArea_id(Integer area_id) {
		this.area_id = area_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getOldpassword() {
		return oldpassword;
	}
	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Long getArrayid() {
		return arrayid;
	}
	public void setArrayid(Long arrayid) {
		this.arrayid = arrayid;
	}
	public String getHead() {
		return head;
	}
	public void setHead(String head) {
		this.head = head;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPay_password() {
		return pay_password;
	}
	public void setPay_password(String pay_password) {
		this.pay_password = pay_password;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	
	
	
}