package com.dh.guangfu.service;

import com.dh.guangfu.po.UserTotal;
import com.dh.system.base.BaseDao;

public interface UserTotalService extends BaseDao{
	
	UserTotal fingByUserId(Long userId);
	
	void update(UserTotal UserTotal);

	void delete(Long arrayid);

	void save(UserTotal UserTotal);
}
