package com.dh.guangfu.service;

import java.util.List;

import com.dh.guangfu.po.TrafficElectricity;
import com.dh.guangfu.vo.TrafficElectricityQuery;
import com.dh.system.base.BaseDao;

public interface TrafficElectricityService extends BaseDao{

	void delete(Long arrayid);

	void save(TrafficElectricity TrafficElectricity);

	List<TrafficElectricity> fingByTrafficElectricityQuery(
			TrafficElectricityQuery trafficElectricityQuery);

	List<TrafficElectricity> fingByUserReport(TrafficElectricityQuery trafficElectricityQuery);
}
