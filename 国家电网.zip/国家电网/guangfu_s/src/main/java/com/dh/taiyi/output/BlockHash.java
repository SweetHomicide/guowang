package com.dh.taiyi.output;

public class BlockHash extends CfosOutput<String> {

	public String getHash() {
		return result;
	}

}
