package com.dh.guangfu.service;

import java.util.List;

import com.dh.guangfu.po.ProductionElectricity;
import com.dh.guangfu.vo.TrafficElectricityQuery;
import com.dh.system.base.BaseDao;

public interface ProductionElectricityService extends BaseDao{
	
	void delete(Long arrayid);

	void save(ProductionElectricity ProductionElectricity);

	List<ProductionElectricity> fingByProductionElectricityQuery(TrafficElectricityQuery trafficElectricityQuery);

	List<ProductionElectricity> fingByUserReport(TrafficElectricityQuery trafficElectricityQuery);
}
