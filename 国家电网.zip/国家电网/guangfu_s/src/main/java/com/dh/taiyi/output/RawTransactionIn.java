package com.dh.taiyi.output;

import com.alibaba.fastjson.annotation.JSONField;

public class RawTransactionIn {

	@JSONField(name = "txid")
	private String txid;

	@JSONField(name = "vout")
	private Integer vout;

	@JSONField(name = "coinbase")
	private String coinbase;

	@JSONField(name = "scriptSig")
	private InScriptSig scriptSig;

	@JSONField(name = "sequence")
	private Long sequence;

	public String getTxid() {
		return txid;
	}

	public void setTxid(String txid) {
		this.txid = txid;
	}

	public Integer getVout() {
		return vout;
	}

	public void setVout(Integer vout) {
		this.vout = vout;
	}

	public InScriptSig getScriptSig() {
		return scriptSig;
	}

	public void setScriptSig(InScriptSig scriptSig) {
		this.scriptSig = scriptSig;
	}

	public Long getSequence() {
		return sequence;
	}

	public void setSequence(Long sequence) {
		this.sequence = sequence;
	}

	public String getCoinbase() {
		return coinbase;
	}

	public void setCoinbase(String coinbase) {
		this.coinbase = coinbase;
	}

}
