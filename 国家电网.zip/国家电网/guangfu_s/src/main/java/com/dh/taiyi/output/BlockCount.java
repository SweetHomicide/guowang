package com.dh.taiyi.output;

public class BlockCount extends CfosOutput<Long> {

	public Long getCount() {
		return result;
	}

}
