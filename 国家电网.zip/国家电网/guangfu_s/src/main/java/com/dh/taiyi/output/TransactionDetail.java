package com.dh.taiyi.output;

import java.math.BigDecimal;

public class TransactionDetail {
	
	private String account;
	
	private String symbol;
	
	private String address;
	
	private String category;
	
	private BigDecimal amount;
	
	private BigDecimal fee;

	public String getAccount() {
		return account;
	}

	public String getSymbol() {
		return symbol;
	}

	public String getAddress() {
		return address;
	}

	public String getCategory() {
		return category;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public BigDecimal getFee() {
		return fee;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public void setFee(BigDecimal fee) {
		this.fee = fee;
	}
	
}
