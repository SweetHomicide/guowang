package com.dh.guangfu.service;

import com.dh.guangfu.po.Electricity;
import com.dh.system.base.BaseDao;
/**
 * cms文章内容管理
 * @author tianjiao
 *
 */
public interface ElectricityService extends BaseDao{
	
	Electricity findById(Long id);
	
	Electricity findByUserId(Integer userId);
	
	void update(Electricity Electricity);
	
	void insert(Electricity Electricity);
	
}
