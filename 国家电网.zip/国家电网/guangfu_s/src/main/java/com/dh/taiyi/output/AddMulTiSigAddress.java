package com.dh.taiyi.output;

public class AddMulTiSigAddress extends CfosOutput<String>{
	public String getMulTiSigAddress(){
		return result;
	}
}