package com.dh.guangfu.service;

import java.util.List;

import com.dh.guangfu.po.UserBank;
import com.dh.system.base.BaseDao;

public interface UserBankService extends BaseDao{
	
	List<UserBank> fingByUserId(Long userId);
	
	void update(UserBank UserBank);

	void delete(Long arrayid);

	void save(UserBank UserBank);
}
